#bin/bash
>$1/out.log;
>$1/error.log;
>$1/incremental_count.text;
