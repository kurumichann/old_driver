#bin/bash
cp -f  $1/bak/resourcelist_bak.json $1/resourcelist.json;
cp -f  $1/bak/totoalrows_bak.text $1/totalrows.text;
cp -f  $1/bak/viewed_list_bak.text $1/viewed_list.text;
cp -f  $1/bak/incremental_list_bak.text $1/incremental_list.text;
cp -f  $1/bak/error_bak.log $1/error.log;
cp -f  $1/bak/out_bak.log $1/out.log
