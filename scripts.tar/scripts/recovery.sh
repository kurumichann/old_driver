#bin/bash
cp -f  bak/resourcelist_bak.json resourcelist.json;
cp -f  bak/totoalrows_bak.text totalrows.text;
cp -f  bak/viewed_list_bak.text viewed_list.text;
cp -f  bak/incremental_list_bak.text incremental_list.text;
cp -f  bak/error_bak.log error.log;
cp -f  bak/out_bak.log out.log
