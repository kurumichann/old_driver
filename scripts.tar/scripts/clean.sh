#bin/bash
>out.log;
>error.log;
>incremental_count.text;
