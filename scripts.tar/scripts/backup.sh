#bin/bash
#back up files
cp -f resourcelist.json bak/resourcelist_bak.json;
cp -f totalrows.text bak/totoalrows_bak.text;
cp -f incremental_list.text bak/incremental_list_bak.text;
cp -f viewed_list.text bak/viewed_list_bak.text;
cp -f erro.log bak/erro_bak.log;
cp -f out.log bak/out_bak.log;
